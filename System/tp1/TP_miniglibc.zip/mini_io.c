#include "mini_lib.h"
MYFILE *file_ptr_constructor()
{
    MYFILE *_ptr = mini_calloc(sizeof(MYFILE), 1);
    _ptr->ind_read = -1;
    _ptr->ind_write = -1;
    _ptr->fd = -1;
    return _ptr;
}
MYFILE *mini_open(char *file, char mode)
{
    MYFILE *open_ptr = file_ptr_constructor();
    switch (mode)
    {
    case OPEN_READ:
    {
        open_ptr->fd = open(file, O_RDONLY);
        if (open_ptr->fd == -1)
        {
            mini_perror("cant open");
            return NULL;
        }

        return open_ptr;
    }
    case OPEN_RW:
    {
        open_ptr->fd = open(file, O_RDWR);
        if (open_ptr->fd == -1)
        {
            mini_perror("cant open");
            return NULL;
        }

        return open_ptr;
    }
    case OPEN_WRITE:
    {
        open_ptr->fd = open(file, O_WRONLY);
        if (open_ptr->fd == -1)
        {
            mini_perror("cant open");
            return NULL;
        }
        return open_ptr;
    }
    case OPEN_ADD_END:
    {
        open_ptr->fd = open(file, O_WRONLY);
        if (open_ptr->fd == -1)
        {
            mini_perror("cant open");
            return NULL;
        }
        return open_ptr;
    }
    default:
        mini_printf("invalid mode input\n");
        break;
    }
}

int mini_fread(void *buffer, int size_element, int number_element, MYFILE *file)
{
    if (!file)
    {
        mini_perror("file NULL");
        return -1;
    }
    if (file->ind_read == -1)
    {
        file->buffer_read = mini_calloc(sizeof(char), IOBUFFER_SIZE);
        file->ind_read = 0;
    }
    for (int i = 0; i < number_element; i++)
    {
        if (file->ind_read >= IOBUFFER_SIZE)
        {
            if (read(file->fd, file->buffer_read, IOBUFFER_SIZE) == -1)
                mini_perror("cant read");
            return IOBUFFER_SIZE;
        }
        else if (file->ind_read == mini_strlen(file->buffer_read))
        {
        }
        else
        {
        }
    }
}